import { useEffect, useRef, useState } from 'react'
import { PyodideProvider } from './pyodide/PyodideProvider'
import Header from './components/Header'
import Footer from './components/Footer'
import Section from './components/Section'
import CodeCell from './components/CodeCell'
import { sections } from './content/sections'
import './App.css'

export default function App() {
  const scrollerRef = useRef(null)
  const sectionRefs = useRef([])
  const [activeIndex, setActiveIndex] = useState(0)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = sectionRefs.current.indexOf(entry.target)
            if (index !== -1) setActiveIndex(index)
          }
        })
      },
      { root: scrollerRef.current, threshold: 0.5 },
    )

    sectionRefs.current.forEach((el) => el && observer.observe(el))
    return () => observer.disconnect()
  }, [])

  function goTo(index) {
    sectionRefs.current[index]?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <PyodideProvider>
      <Header />

      <main className="scroller" ref={scrollerRef}>
        {sections.map((s, i) => (
          <Section
            key={s.id}
            ref={(el) => (sectionRefs.current[i] = el)}
            eyebrow={s.eyebrow}
            title={s.title}
          >
            <p>{s.body}</p>
            <CodeCell initialCode={s.code} />
          </Section>
        ))}
      </main>

      <Footer sections={sections} activeIndex={activeIndex} onNavigate={goTo} />
    </PyodideProvider>
  )
}
