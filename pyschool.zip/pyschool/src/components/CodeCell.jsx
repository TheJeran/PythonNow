import { useMemo, useState } from 'react'
import CodeMirror, { EditorView } from '@uiw/react-codemirror'
import { python } from '@codemirror/lang-python'
import { usePyodide } from '../pyodide/PyodideProvider'
import './CodeCell.css'

// A minimal dark theme so we don't pull in an extra theme package.
const cellTheme = EditorView.theme(
  {
    '&': { fontSize: '0.9rem', backgroundColor: 'transparent' },
    '.cm-content': { fontFamily: 'var(--font-mono)', padding: '0.75rem 0' },
    '.cm-gutters': { backgroundColor: 'transparent', border: 'none', color: 'var(--text-dim)' },
    '.cm-activeLine': { backgroundColor: 'rgba(232,179,57,0.06)' },
    '.cm-activeLineGutter': { backgroundColor: 'transparent' },
    '&.cm-focused': { outline: 'none' },
  },
  { dark: true },
)

let cellCount = 0

export default function CodeCell({ initialCode }) {
  const { status, run } = usePyodide()
  const [code, setCode] = useState(initialCode.trim())
  const [output, setOutput] = useState(null)
  const [error, setError] = useState(null)
  const [running, setRunning] = useState(false)
  const [execCount, setExecCount] = useState(null)

  const extensions = useMemo(() => [python(), cellTheme], [])

  async function handleRun() {
    if (status !== 'ready' || running) return
    setRunning(true)
    const result = await run(code)
    setOutput(result.output)
    setError(result.error)
    setExecCount((++cellCount))
    setRunning(false)
  }

  function handleKeyDown(e) {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault()
      handleRun()
    }
  }

  return (
    <div className="cell" onKeyDown={handleKeyDown}>
      <div className="cell-row">
        <span className="cell-prompt">In [{execCount ?? ' '}]:</span>
        <div className="cell-editor">
          <CodeMirror
            value={code}
            onChange={setCode}
            extensions={extensions}
            basicSetup={{ lineNumbers: false, foldGutter: false }}
          />
        </div>
      </div>

      <div className="cell-actions">
        <button onClick={handleRun} disabled={status !== 'ready' || running}>
          {status !== 'ready' ? 'loading python…' : running ? 'running…' : 'Run ▸'}
        </button>
        <span className="cell-hint">⌘/Ctrl + Enter</span>
      </div>

      {(output || error) && (
        <div className="cell-row">
          <span className="cell-prompt cell-prompt--out">Out[{execCount}]:</span>
          <pre className={`cell-output ${error ? 'cell-output--error' : ''}`}>
            {error ?? output}
          </pre>
        </div>
      )}
    </div>
  )
}
